from django.http import HttpResponse
from django.shortcuts import render
from .models import *
from django.core.paginator import Paginator
from .models import Objectss  # 导入模型
import datetime
from django.http import JsonResponse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.db import transaction
import logging
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.http import require_http_methods
import json


# Create your views here.
def toLogin_view(request):
    return render(request, 'login.html')

def Login_view(request):
    u = request.POST.get("user", '')
    p = request.POST.get("pwd", '')

    if u and p:
        c = StudentInfo.objects.filter(stu_name= u,stu_psw= p).count()
        if c >= 1:
            return render(request, 'login_successful.html')
        else:
            return render(request, 'login_fail.html')
    else:
        return render(request, 'login_fail.html')


# views.py
from django.shortcuts import render
from .models import Objectss  # 导入模型

def home_view(request):
    # 获取排序和筛选参数
    sort_order = request.GET.get('sort')
    kind_filter = request.GET.get('kind')  # 获取筛选的 kind 值

    # 初始查询所有数据
    items = Objectss.objects.all()

    # 筛选逻辑
    if kind_filter:
        items = items.filter(kind=kind_filter)  # 按 kind 筛选

    # 排序逻辑
    if sort_order == 'price_asc':
        items = items.order_by('price')  # 价格升序
    elif sort_order == 'price_desc':
        items = items.order_by('-price')  # 价格降序

    # 传递所有 kind 选项到模板
    KIND_CHOICES = Objectss.KIND_CHOICES
    context = {
        "items": items,
        "sort_order": sort_order,
        "kind_filter": kind_filter,
        "KIND_CHOICES": Objectss.KIND_CHOICES  # 必须传这个！
    }
    return render(request, 'home.html', context)



#点击注册按钮后的逻辑
def register_view(request):
    return render(request, 'register.html')

def or_register_view(request):
    u = request.POST.get("user", '')
    p = request.POST.get("pwd", '')
    if u and p:
        stu = StudentInfo(stu_name=u, stu_psw=p)
        stu.save()
        return render(request, 'register_successful.html')
    else:
        return HttpResponse("请输入完整的账号跟密码！")





def home2_view(request):
    # 获取排序和筛选参数
    sort_order = request.GET.get('sort')
    kind_filter = request.GET.get('kind')  # 获取筛选的 kind 值

    # 初始查询所有数据
    items = Objectss2.objects.all()

    # 筛选逻辑
    if kind_filter:
        items = items.filter(kind=kind_filter)  # 按 kind 筛选

    # 排序逻辑
    if sort_order == 'price_asc':
        items = items.order_by('price')  # 价格升序
    elif sort_order == 'price_desc':
        items = items.order_by('-price')  # 价格降序

    # 传递所有 kind 选项到模板
    KIND_CHOICES = Objectss2.KIND_CHOICES
    context = {
        "items": items,
        "sort_order": sort_order,
        "kind_filter": kind_filter,
        "KIND_CHOICES": Objectss2.KIND_CHOICES  # 必须传这个！
    }
    return render(request, 'home2.html', context)


def home3_view(request):
    items = Objectss3.objects.all()
    return render(request, 'home3.html',{"items": items})

def market_view(request):
    return render(request,'market.html')

def charge_view(request):
    return render(request,'charge.html')



@csrf_protect
@require_http_methods(["POST"])
def claim_surprise(request):
    try:
        today = timezone.now().date()
        # 检查今日是否已领取
        has_claimed = Objectss3.objects.filter(
            id=1,
            created_at__date=today
        ).exists()

        if has_claimed:
            return JsonResponse({"status": "error", "msg": "今日已领取过，请明天再来～"})

        # 尝试更新或创建记录
        obj, created = Objectss3.objects.update_or_create(
            id=1,
            defaults={
                "name": "谜之盒",
                "price": 100,
                "quantity": 1,
                "image_path": "images/mizhihe.png",
                "created_at": timezone.now()
            }
        )

        return JsonResponse({"status": "success", "msg": "领取成功！"})
    except Exception as e:
        return JsonResponse({"status": "error", "msg": f"操作失败: {str(e)}"})

@require_http_methods(["GET"])
def check_claim_status(request):
    try:
        today = timezone.now().date()
        has_claimed = Objectss3.objects.filter(
            id=1,
            created_at__date=today
        ).exists()
        return JsonResponse({"has_claimed": has_claimed})
    except Exception as e:
        return JsonResponse({"has_claimed": False, "error": str(e)})


@csrf_protect
@require_http_methods(["POST"])
def reset_claim_status(request):
    try:
        # 删除今日的领取记录（仅用于开发测试，生产环境需谨慎）
        today = timezone.now().date()
        Objectss3.objects.filter(
            id=1,
            created_at__date=today
        ).delete()

        return JsonResponse({"status": "success", "msg": "重置成功，可重新领取"})
    except Exception as e:
        return JsonResponse({"status": "error", "msg": f"重置失败: {str(e)}"})


# 在views.py中添加
def market_view(request):
    # 获取市场所有商品
    market_items = marketList.objects.all()
    return render(request, 'market.html', {'market_items': market_items})


@csrf_protect
@require_http_methods(["POST"])
def add_to_objectss3(request):
    try:
        data = json.loads(request.body)

        # 创建新的Objectss3记录
        new_item = Objectss3(
            name=data['name'],
            price=data['price'],
            quantity=data['quantity'],
            image_path=data['image_path'],
            introduce=data['introduce'],
            created_at=timezone.now()
        )
        new_item.save()

        return JsonResponse({"success": True})
    except Exception as e:
        return JsonResponse({"success": False, "message": str(e)})

def raffle_view(request):
        return render(request, 'raffle.html')



def get_raffle_items(request):
    """提供抽奖物品数据的API"""
    items = raffleList.objects.all()
    item_list = []
    for item in items:
        item_list.append({
            'id': item.id,
            'name': item.name,
            'price': float(item.price),
            'quantity': item.quantity,
            'image_path': item.image_path,
            'introduce': item.introduce
        })
    return JsonResponse(item_list, safe=False)


@csrf_protect
@require_http_methods(["POST"])
def add_to_objectss3(request):
    try:
        data = json.loads(request.body)

        # 创建或更新物品记录
        obj, created = Objectss3.objects.update_or_create(
            name=data['name'],
            defaults={
                'price': data['price'],
                'quantity': data.get('quantity', 1),
                'image_path': data['image_path'],
                'introduce': data.get('introduce', '')
            }
        )

        return JsonResponse({"success": True, "message": "物品已添加到仓库"})
    except Exception as e:
        return JsonResponse({"success": False, "message": str(e)})

