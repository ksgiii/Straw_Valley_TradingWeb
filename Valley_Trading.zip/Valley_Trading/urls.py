from django.urls import path

from . import views

urlpatterns = [
    path('', views.toLogin_view, name='login'),
    path('index/', views.Login_view, name='index'),
    path('index/home/', views.home_view,name='home'),
    path('index/register/', views.register_view,name='register'),
    path('index/register/or_register', views.or_register_view,name='or_register'),

    path('index/home/home2/', views.home2_view, name='home2'),
    path('index/home/home3/', views.home3_view, name='home3'),
    path('index/home/market/', views.market_view, name='market'),
    path('index/home/charge/', views.charge_view, name='charge'),



path('claim_surprise/', views.claim_surprise, name='claim_surprise'),
path('check_claim_status/', views.check_claim_status, name='check_claim_status'),

# urls.py 中惊喜功能的路由
path('index/home/home3/claim_surprise/', views.claim_surprise),
path('index/home/home3/check_claim_status/', views.check_claim_status),

path('reset_claim_status/', views.reset_claim_status, name='reset_claim_status'),
path('index/home/home3/reset_claim_status/', views.reset_claim_status),


# 在urls.py中添加
path('market/', views.market_view, name='market'),
path('add_to_objectss3/', views.add_to_objectss3, name='add_to_objectss3'),

path('raffle/', views.raffle_view, name='raffle'),




path('api/raffle-items/', views.get_raffle_items, name='get_raffle_items'),
path('api/add-to-objectss3/', views.add_to_objectss3, name='add_to_objectss3'),  # 确保这个路由也存在
]