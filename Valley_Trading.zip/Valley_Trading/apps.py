from django.apps import AppConfig


class ValleyTradingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "Valley_Trading"
