from django.utils import timezone  # 导入timezone

from django.db import models

# Create your models here.
class StudentInfo(models.Model):
    stu_id = models.CharField(primary_key=True, max_length=20)
    stu_name = models.CharField(max_length=20)
    stu_psw = models.CharField(max_length=20)

class Objectss(models.Model):
    name = models.CharField(max_length=20)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField()
    image_path=models.CharField(max_length=200)
    KIND_CHOICES = (
        (1, '采集品'),
        (2, '种植物'),
        (3, '架子作物'),
        (4, '水果'),
        (5, '收集品'),
    )
    # 使用 choices 限制可选值
    kind = models.IntegerField(choices=KIND_CHOICES)

    class Meta:
        db_table = 'valley_trading_objectss'



class Objectss2(models.Model):
    name = models.CharField(max_length=20)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField()
    image_path=models.CharField(max_length=200)
    KIND_CHOICES = (
        (1, '宝石'),
        (2, '矿物'),
        (3, '晶球'),
        (4, '材料'),
    )
    # 使用 choices 限制可选值
    kind = models.IntegerField(choices=KIND_CHOICES)
    class Meta:
        db_table = 'valley_trading_objectss2'

class Objectss3(models.Model):
    name = models.CharField(max_length=20)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField()
    image_path=models.CharField(max_length=200)
    created_at = models.DateTimeField(default=timezone.now,null=True)  # 添加这个字段
    introduce=models.CharField(max_length=200)

    class Meta:
        db_table = 'valley_trading_objectss3'

class marketList(models.Model):
    name = models.CharField(max_length=20)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField(default=1)
    image_path = models.CharField(max_length=200)
    created_at = models.DateTimeField(default=timezone.now, null=True)  # 添加这个字段
    introduce = models.CharField(max_length=200)

    class Meta:
        db_table = 'valley_trading_marketlist'


class raffleList(models.Model):
    name = models.CharField(max_length=20)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField(default=1)
    image_path = models.CharField(max_length=200)
    created_at = models.DateTimeField(default=timezone.now, null=True)  # 添加这个字段
    introduce = models.CharField(max_length=200)

    class Meta:
        db_table = 'valley_trading_rafflelist'
